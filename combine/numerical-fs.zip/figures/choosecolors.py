from matplotlib.cm import get_cmap

plt.figure(figsize=(5,5))

nlin = 5 ## number of lines to plot
npts = 10
xdt = nprnd.rand(npts, nlin)
xax = np.arange(npts)

cmname = 'Paired'
cmp = get_cmap(cmname)

for ii in np.arange(nlin):
    plt.plot(xax, xdt[:,ii], c = cmp(ii/nlin))
    plt.plot(xax[0], xdt[0,ii], '*', c = cmp(ii/nlin), ms=10)
    plt.plot(xax[-1], xdt[-1,ii], 'o', c = cmp(ii/nlin))
    tt = plt.title('Same colors for the line, and the initial and final * and o')

plt.show()
